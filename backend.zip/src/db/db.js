const mongoose = require('mongoose')
// const DB = process.env.DB;
mongoose.connect("mongodb+srv://as-irfani:naGoijyEu4a2Wlt0@cluster0.xlrmevr.mongodb.net/?retryWrites=true&w=majority", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(() => {
    console.log("Connection successful")
}).catch((e) => { console.log(`No Connection ${e}`) })


// DB = "mongodb+srv://abbasdev546:hGGAdwiIkgJUVoDR@cluster0.s9b68hd.mongodb.net/alizaibuilder?retryWrites=true&w=majority"
// // 